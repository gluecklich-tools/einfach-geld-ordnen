README_START_HIER.txt

Paket: EGO Freebie (Haushaltsbuch Mini)

Inhalt:
- EGO_Freebie.xlsx  (Excel)
- EGO_Freebie.ods   (LibreOffice)

Hinweise:
- Self-Serve: offline nutzbar, einmaliger Download.
- Keine Updates, kein Support, keine Service-Versprechen.
- Dateien zuerst lokal speichern, dann im Programm öffnen.

Zeilenlimits (Orientierung):
- Freebie: 5.000
- Pro:    10.000
- Voll:   20.000
