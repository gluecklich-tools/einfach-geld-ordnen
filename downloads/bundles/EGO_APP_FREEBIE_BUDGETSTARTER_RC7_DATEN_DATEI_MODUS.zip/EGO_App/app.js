const EGO_PRODUCT = {"title":"EGO Budgetstarter","pages":["BEDIENUNG","START","PARAMETER","HAUSHALTSBUCH","BUDGETS","HINWEISE","LIZENZ"],"note":"Kostenloser Einstieg mit Haushaltsbuch, Budgetübersicht und Finanzhinweisen.","limits":{"entries":20}};
const allPages = [
  ["BEDIENUNG","Onboarding"],["START","Finanz-Cockpit"],["PARAMETER","Grundeinstellungen"],["LISTEN","Kategorien"],
  ["HAUSHALTSBUCH","Tägliche Eingabe"],["FIXKOSTEN","Wiederkehrendes"],["BUDGETS","Budgetsteuerung"],["PLANUNG","Vorausdenken"],
  ["MONAT","Monatsanalyse"],["HINWEISE","Finanzcoach"],["MONATSABSCHLUSS","Checkliste"],["JAHR","Jahresüberblick"],
  ["NOTGROSCHEN","Sicherheit"],["SCHULDEN","Abbauplan"],["STEUER","Steuerwerte"],["SPARZIELE","Ziele"],["LIZENZ","Abschluss"]
];
const pages = allPages.filter(p => EGO_PRODUCT.pages.includes(p[0]));

function thisMonth(){return new Date().toISOString().slice(0,7)}
const demoMonth = thisMonth();

const demoData = {
  activeMonth: demoMonth,
  params: {name:"Carsten", startMonth:demoMonth, income:2500, reserveGoal:6000, savingsRateGoal:10, budgetWarn:90, budgetCritical:100},
  categories:["Lebensmittel","Miete","Mobilität","Freizeit","Gesundheit","Haushalt","Versicherung","Einkommen","Sparen","Sonstiges"],
  payments:["Konto","Bar","Karte","PayPal"],
  entries:[
    {date:demoMonth+"-01", desc:"Gehalt", category:"Einkommen", type:"Einnahme", amount:2500, payment:"Konto", note:"Beispiel"},
    {date:demoMonth+"-03", desc:"Wocheneinkauf", category:"Lebensmittel", type:"Ausgabe", amount:85, payment:"Karte", note:"Beispiel"},
    {date:demoMonth+"-06", desc:"Tanken", category:"Mobilität", type:"Ausgabe", amount:70, payment:"Karte", note:"Beispiel"},
    {date:demoMonth+"-10", desc:"Apotheke", category:"Gesundheit", type:"Ausgabe", amount:28, payment:"Karte", note:"Beispiel"},
    {date:addMonths(demoMonth,-1)+"-01", desc:"Gehalt", category:"Einkommen", type:"Einnahme", amount:2500, payment:"Konto", note:"Historie"},
    {date:addMonths(demoMonth,-1)+"-05", desc:"Lebensmittel", category:"Lebensmittel", type:"Ausgabe", amount:420, payment:"Karte", note:"Historie"},
    {date:addMonths(demoMonth,-2)+"-01", desc:"Gehalt", category:"Einkommen", type:"Einnahme", amount:2500, payment:"Konto", note:"Historie"},
    {date:addMonths(demoMonth,-2)+"-07", desc:"Freizeit", category:"Freizeit", type:"Ausgabe", amount:180, payment:"Karte", note:"Historie"}
  ],
  fixed:[
    {name:"Miete", category:"Miete", rhythm:"Monatlich", amount:600},
    {name:"Internet", category:"Haushalt", rhythm:"Monatlich", amount:40},
    {name:"Versicherung", category:"Versicherung", rhythm:"Jährlich", amount:360},
    {name:"Handy", category:"Haushalt", rhythm:"Monatlich", amount:20}
  ],
  budgets:[
    {category:"Lebensmittel", budget:350},
    {category:"Mobilität", budget:180},
    {category:"Freizeit", budget:120},
    {category:"Gesundheit", budget:80},
    {category:"Haushalt", budget:150}
  ],
  special:[
    {month:addMonths(demoMonth,1), desc:"Autoversicherung", amount:300},
    {month:addMonths(demoMonth,3), desc:"Geschenk / Sonderkosten", amount:150}
  ],
  reserve:{current:1200, monthly:150},
  debts:[{name:"Beispielkredit", balance:1200, rate:100, interest:0}],
  taxes:[{name:"Arbeitsmittel", amount:120, note:"Beispiel"}],
  goals:[{name:"Urlaub", goal:1200, current:250, monthly:100},{name:"PC", goal:1800, current:400, monthly:150}],
  checks:{}
};

function emptyData(){
  return {
    activeMonth:thisMonth(),
    params:{name:"", startMonth:thisMonth(), income:0, reserveGoal:0, savingsRateGoal:10, budgetWarn:90, budgetCritical:100},
    categories:["Lebensmittel","Miete","Mobilität","Freizeit","Gesundheit","Haushalt","Versicherung","Einkommen","Sparen","Sonstiges"],
    payments:["Konto","Bar","Karte","PayPal"],
    entries:[], fixed:[], budgets:[], special:[], reserve:{current:0, monthly:0}, debts:[], taxes:[], goals:[], checks:{}
  };
}

let state = load();
let currentPage = "START";

const euro = n => new Intl.NumberFormat("de-DE",{style:"currency",currency:"EUR",maximumFractionDigits:0}).format(Number(n||0));
const pct = n => `${Math.round(Number(n||0))}%`;
const byId = id => document.getElementById(id);

function deepClone(o){return JSON.parse(JSON.stringify(o));}
function load(){
  try {
    const raw=JSON.parse(localStorage.getItem("egoAppData")||"null");
    const loaded = raw ? normalize(raw) : deepClone(demoData); state = loaded; enforceProductLimits(false); return state;
  } catch { return deepClone(demoData); }
}
function normalize(d){
  return {...deepClone(emptyData()), ...d,
    params:{...emptyData().params, ...(d.params||{})},
    reserve:{...emptyData().reserve, ...(d.reserve||{})},
    entries:d.entries||[], fixed:d.fixed||[], budgets:d.budgets||[], special:d.special||[],
    debts:d.debts||[], taxes:d.taxes||[], goals:d.goals||[], checks:d.checks||{}
  };
}
function save(){localStorage.setItem("egoAppData", JSON.stringify(state)); toast("Gespeichert");}
function toast(text){const t=byId("toast"); t.textContent=text; t.classList.add("show"); setTimeout(()=>t.classList.remove("show"),1500);}
function monthOf(date){return String(date||"").slice(0,7);}
function inMonth(row, month=state.activeMonth){return monthOf(row.date)===month;}
function fixedMonthly(f){const a=Number(f.amount||0); if(f.rhythm==="Jährlich") return a/12; if(f.rhythm==="Quartalsweise") return a/3; return a;}
function fixedTotal(){return state.fixed.reduce((s,f)=>s+fixedMonthly(f),0);}
function amountEntries(type=null, month=state.activeMonth){
  return state.entries.filter(e=>inMonth(e, month)).filter(e=>!type || e.type===type).reduce((s,e)=>s+Number(e.amount||0),0);
}
function incomeForMonth(month=state.activeMonth){return amountEntries("Einnahme", month) || Number(state.params.income||0);}
function entryExpensesForMonth(month=state.activeMonth){return amountEntries("Ausgabe", month);}
function specialForMonth(month=state.activeMonth){return state.special.filter(s=>s.month===month).reduce((s,x)=>s+Number(x.amount||0),0);}
function expensesForMonth(month=state.activeMonth){return entryExpensesForMonth(month) + fixedTotal() + specialForMonth(month);}
function saldoForMonth(month=state.activeMonth){return incomeForMonth(month)-expensesForMonth(month);}
function savingsRateForMonth(month=state.activeMonth){return incomeForMonth(month)? Math.max(0, saldoForMonth(month))/incomeForMonth(month)*100 : 0;}
function categorySpent(cat, month=state.activeMonth){
  const entries = state.entries.filter(e=>inMonth(e, month)).filter(e=>e.type==="Ausgabe" && e.category===cat).reduce((s,e)=>s+Number(e.amount||0),0);
  const fixed = state.fixed.filter(f=>f.category===cat).reduce((s,f)=>s+fixedMonthly(f),0);
  return entries+fixed;
}
function reserveProgress(){return Math.min(100, Number(state.reserve.current||0)/Math.max(1,Number(state.params.reserveGoal||1))*100);}
function budgetStatusForMonth(month=state.activeMonth){
  const warn=Number(state.params.budgetWarn||90), critical=Number(state.params.budgetCritical||100);
  let worst="Grün";
  for(const b of state.budgets){
    const usage= b.budget ? categorySpent(b.category, month)/b.budget*100 : 0;
    if(usage>=critical) return "Rot";
    if(usage>=warn) worst="Gelb";
  }
  return worst;
}
function statusClass(s){return s==="Rot"?"bad":s==="Gelb"?"warn":"ok";}
function badge(s){return `<span class="badge ${statusClass(s)}">${s}</span>`}
function neutralBadge(s){return `<span class="badge neutral">${s}</span>`}
function progress(value, cls=""){ return `<div class="progress ${cls}"><span style="width:${Math.max(0,Math.min(100,value))}%"></span></div>`; }

function entryLimit(){ return EGO_PRODUCT?.limits?.entries || Infinity; }
function enforceProductLimits(showNotice=false){
  const limit = entryLimit();
  if(Number.isFinite(limit) && state.entries.length > limit){
    state.entries = state.entries.slice(0, limit);
    if(showNotice) toast(`Budgetstarter ist auf ${limit} Buchungen begrenzt.`);
  }
}
function limitNotice(){
  const limit = entryLimit();
  if(!Number.isFinite(limit)) return "";
  return `<div class="card" style="border-left:5px solid var(--gold)"><strong>Budgetstarter-Grenze:</strong> Diese kostenlose Version ist auf ${limit} Buchungen begrenzt. Für volle Nutzung ist die Vollversion gedacht.</div>`;
}

function init(){
  const nav=byId("nav");
  nav.innerHTML=pages.map((p,i)=>`<button data-page="${p[0]}"><span class="num">${i+1}</span><span>${p[0]}<small>${p[1]}</small></span></button>`).join("");
  nav.addEventListener("click",e=>{
    const btn=e.target.closest("button[data-page]");
    if(!btn) return;
    currentPage=btn.dataset.page; render();
  });
  byId("activeMonth").value=state.activeMonth;
  byId("activeMonth").addEventListener("change",e=>{state.activeMonth=e.target.value; render();});
  byId("saveButton").addEventListener("click",save);
  byId("exportJson").addEventListener("click",exportExcelFile);
  byId("importJson").addEventListener("change",importExcelFile);
  byId("demoButton").addEventListener("click",()=>{ if(confirm("Demo-Daten laden und aktuelle Daten ersetzen?")){state=deepClone(demoData); enforceProductLimits(false); save(); render();} });
  byId("resetButton").addEventListener("click",()=>{ if(confirm("Wirklich leer starten? Aktuelle lokale Daten werden ersetzt.")){state=emptyData(); enforceProductLimits(false); save(); render();} });
  if("serviceWorker" in navigator && location.protocol.startsWith("http")) navigator.serviceWorker.register("sw.js").catch(()=>{});
  render();
}
function render(){
  byId("pageTitle").textContent=currentPage;
  byId("activeMonth").value=state.activeMonth;
  document.querySelectorAll(".nav button").forEach(b=>b.classList.toggle("active",b.dataset.page===currentPage));
  const v=byId("view");
  v.innerHTML = views[currentPage] ? views[currentPage]() : genericPage(currentPage);
  bindInputs(v);
}
function bindInputs(root){
  root.querySelectorAll("[data-bind]").forEach(el=>{
    const fn=()=>{setPath(el.dataset.bind, el.type==="number"? Number(el.value): el.value); saveSilent(); render();};
    el.addEventListener("change", fn);
    if(el.tagName==="INPUT" && el.type!=="date" && el.type!=="month") el.addEventListener("blur", fn);
  });
  root.querySelectorAll("[data-action]").forEach(el=>{ if(el.tagName!=="INPUT") el.addEventListener("click",()=>actions[el.dataset.action]?.(el.dataset)); });
  root.querySelectorAll("input[type=file][data-action=loadExcel]").forEach(el=>el.addEventListener("change",importExcelFile));
}
function saveSilent(){localStorage.setItem("egoAppData", JSON.stringify(state));}
function setPath(path,value){
  const parts=path.split(".");
  let obj=state;
  while(parts.length>1){ obj=obj[parts.shift()]; }
  obj[parts[0]]=value;
}
function getPath(path){return path.split(".").reduce((o,k)=>o?.[k],state);}
function input(path,type="text"){
  const val=getPath(path) ?? "";
  return `<input ${type==="number"?'type="number" step="0.01"':'type="'+type+'"'} value="${String(val).replaceAll('"',"&quot;")}" data-bind="${path}">`;
}
function select(path, options){
  const val=getPath(path) ?? "";
  return `<select data-bind="${path}">${options.map(o=>`<option ${o===val?'selected':''}>${o}</option>`).join("")}</select>`;
}
function table(headers, rows){return `<div class="table-card card"><div class="table-header"><h3>${headers.title||"Tabelle"}</h3><span>${headers.note||""}</span></div><div class="table-wrap"><table><thead><tr>${headers.cols.map(h=>`<th>${h}</th>`).join("")}</tr></thead><tbody>${rows || `<tr><td colspan="${headers.cols.length}" class="mini-muted">Noch keine Einträge vorhanden.</td></tr>`}</tbody></table></div></div>`;}
function hero(title, text, pills=[]){return `<section class="hero"><h2>${title}</h2><p>${text}</p><div class="hero-meta">${pills.map(p=>`<span class="pill">${p}</span>`).join("")}</div></section>`;}


function dataFileModeCard(){
  return `<div class="card data-mode-card">
    <div class="section-title"><h3>Daten-Datei-Modus</h3><span>PC und Android austauschbar</span></div>
    <p class="mini-muted">Diese App arbeitet lokal. Für Sicherung und Gerätewechsel nutzt du eine Excel-Datei.</p>
    <div class="data-actions">
      <button class="save-excel" data-action="saveExcel">Excel-Datei speichern</button>
      <label class="load-excel file-proxy">Excel-Datei laden<input type="file" accept=".xls,.xml,application/vnd.ms-excel,text/xml" data-action="loadExcel"></label>
    </div>
    <div class="warning-soft">Vor Browserwechsel, Gerätewechsel oder Zurücksetzen des Geräts immer zuerst „Excel-Datei speichern“ nutzen.</div>
  </div>`;
}

const views = {
  BEDIENUNG(){
    return `${hero("EGO – Einfach Geld ordnen","Ein Finanzsystem für Menschen, die sofort sehen wollen, was reinkommt, was rausgeht und was am Monatsende wirklich frei bleibt.",["Gelb = Eingabe","Weiß = Automatik","Blau = Orientierung","Gold = Fortschritt"])}
    <div class="grid grid-3">
      ${[["1","Parameter einrichten","Name, Startmonat, Einkommen, Ziele und Schwellen einmal sauber hinterlegen."],
      ["2","Fixkosten erfassen","Miete, Strom, Internet, Versicherungen und Abos vollständig eintragen."],
      ["3","Buchungen eintragen","Einnahmen und Ausgaben im Haushaltsbuch täglich oder wöchentlich ergänzen."],
      ["4","Monat prüfen","START, BUDGETS und MONAT zeigen dir sofort, wo du stehst."],
      ["5","Jahr auswerten","JAHR, SPARZIELE, NOTGROSCHEN und SCHULDEN zeigen die Entwicklung."],
      ["✓","Verkaufen / nutzen","Lokale Daten bleiben im Browser. Exportiere regelmäßig eine JSON-Sicherung."]].map(s=>`<div class="card step-card"><div class="step-num">${s[0]}</div><div><h3>${s[1]}</h3><p>${s[2]}</p></div></div>`).join("")}
    </div>`;
  },
  START(){
    const bs=budgetStatusForMonth(state.activeMonth);
    const coach = buildCoach(state.activeMonth).slice(0,3);
    const months=lastMonths(state.activeMonth,6);
    return `${hero(`Finanz-Cockpit ${formatMonth(state.activeMonth)}`,"Alle wichtigen Zahlen auf einen Blick: Einnahmen, Ausgaben, Saldo, Sparquote, Notgroschen und Budgetstatus.",["Finanzen im Griff","Automatisch berechnet","Nächste Schritte sichtbar"])}
    ${dataFileModeCard()}<div class="grid grid-6">
      ${kpi("Einnahmen",euro(incomeForMonth()),"Monatliche Eingänge")}
      ${kpi("Ausgaben",euro(expensesForMonth()),"Buchungen + Fixkosten + Sonderkosten")}
      ${kpi("Saldo",euro(saldoForMonth()), saldoForMonth()>=0?"positiver Monatsstand":"prüfen und gegensteuern")}
      ${kpi("Sparquote",pct(savingsRateForMonth()),`Ziel: ${state.params.savingsRateGoal}%`)}
      ${kpi("Notgroschen",pct(reserveProgress()),progress(reserveProgress(),"ok"))}
      ${kpi("Budgetstatus",badge(bs),bs==="Grün"?"Alles im Rahmen":bs==="Gelb"?"Beobachten":"Sofort prüfen")}
    </div>
    <div class="grid grid-2">
      <div class="card"><div class="section-title"><h3>Nächste Schritte</h3><span>dynamisch</span></div><div class="coach-list">${coach.map(c=>coachItem(c)).join("")}</div></div>
      <div class="card chart-card"><div class="section-title"><h3>Monatstrend</h3><span>letzte 6 Monate</span></div><div class="chart">${lineChart(months)}</div></div>
    </div>
    <div class="card"><div class="section-title"><h3>Ausgaben nach Bereich</h3><span>aktueller Monat</span></div>${bars(state.budgets.map(b=>[b.category,categorySpent(b.category),b.budget || 1]))}</div>`;
  },
  PARAMETER(){
    return `${hero("Grundeinstellungen","Hier wird die App einmal eingerichtet. Gelbe Felder sind Eingaben, weiße Felder werden automatisch genutzt.",["Einmal einrichten","Ziele definieren","Schwellen steuern"])}
    <div class="grid grid-2">
      ${formCard("Persönliche Daten",[["Name","params.name"],["Startmonat","params.startMonth","month"]])}
      ${formCard("Finanzielle Basis",[["Monatliches Einkommen","params.income","number"]])}
      ${formCard("Ziele",[["Notgroschen-Ziel","params.reserveGoal","number"],["Sparquote-Ziel %","params.savingsRateGoal","number"]])}
      ${formCard("Systemwerte",[["Budget-Warnung %","params.budgetWarn","number"],["Budget kritisch %","params.budgetCritical","number"]])}
    </div>`;
  },
  LISTEN(){
    return `${hero("Listen","Kategorien und Zahlungsarten für Dropdowns und Auswertungen. Ruhig, sachlich, ohne Dashboard.",["Kategorien","Zahlungsarten","Zuordnung"])}
    <div class="grid grid-2">${simpleList("Kategorien","categories")}${simpleList("Zahlungsarten","payments")}</div>`;
  },
  HAUSHALTSBUCH(){
    const rows=state.entries.map((e,i)=>`<tr>
      <td class="edit"><input type="date" value="${e.date||""}" data-bind="entries.${i}.date"></td>
      <td class="edit"><input value="${escapeAttr(e.desc)}" data-bind="entries.${i}.desc"></td>
      <td class="edit">${select(`entries.${i}.category`,state.categories)}</td>
      <td class="edit">${select(`entries.${i}.type`,["Einnahme","Ausgabe"])}</td>
      <td class="edit"><input type="number" step="0.01" value="${e.amount||0}" data-bind="entries.${i}.amount"></td>
      <td class="edit">${select(`entries.${i}.payment`,state.payments)}</td>
      <td class="edit"><input value="${escapeAttr(e.note||"")}" data-bind="entries.${i}.note"></td>
      <td><button class="small danger" data-action="delEntry" data-index="${i}">Löschen</button></td>
    </tr>`).join("");
    return `${hero("Haushaltsbuch","Hier arbeitet der Käufer täglich. Einnahmen und Ausgaben eintragen, der Rest wird automatisch ausgewertet.",["Datum","Beschreibung","Kategorie","Typ","Betrag"])}
    <div class="grid grid-4">
      ${kpi("Einnahmen",euro(amountEntries("Einnahme")),"im gewählten Monat")}
      ${kpi("Ausgaben",euro(amountEntries("Ausgabe")),"ohne Fixkosten")}
      ${kpi("Fixkosten",euro(fixedTotal()),"monatlich gerechnet")}
      ${kpi("Saldo",euro(saldoForMonth()),"inklusive Fixkosten")}
    </div>
    ${limitNotice()}<div class="actions"><button class="primary-btn" data-action="addEntry">Neue Buchung</button></div>
    ${table({title:"Tägliche Eingabe",note:"Gelb = bearbeiten",cols:["Datum","Beschreibung","Kategorie","Typ","Betrag","Zahlungsart","Notiz",""]},rows)}`;
  },
  FIXKOSTEN(){
    const rows=state.fixed.map((f,i)=>`<tr>
      <td class="edit"><input value="${escapeAttr(f.name)}" data-bind="fixed.${i}.name"></td>
      <td class="edit">${select(`fixed.${i}.category`,state.categories)}</td>
      <td class="edit">${select(`fixed.${i}.rhythm`,["Monatlich","Quartalsweise","Jährlich"])}</td>
      <td class="edit"><input type="number" step="0.01" value="${f.amount||0}" data-bind="fixed.${i}.amount"></td>
      <td>${euro(fixedMonthly(f))}</td>
      <td><button class="small danger" data-action="delFixed" data-index="${i}">Löschen</button></td>
    </tr>`).join("");
    return `${hero("Fixkosten","Alle wiederkehrenden Kosten: Miete, Internet, Handy, Versicherungen, Strom, Abos.",["Monatliche Summe: "+euro(fixedTotal())])}
    <div class="actions"><button class="primary-btn" data-action="addFixed">Fixkosten ergänzen</button></div>
    ${table({title:"Wiederkehrende Kosten",note:"Jährlich und quartalsweise werden auf Monat umgerechnet",cols:["Name","Kategorie","Rhythmus","Betrag","Monatswert",""]},rows)}`;
  },
  BUDGETS(){
    const rows=state.budgets.map((b,i)=>{
      const spent=categorySpent(b.category), diff=Number(b.budget||0)-spent, usage=b.budget?spent/b.budget*100:0;
      const st=usage>=state.params.budgetCritical?"Rot":usage>=state.params.budgetWarn?"Gelb":"Grün";
      return `<tr>
      <td class="edit">${select(`budgets.${i}.category`,state.categories)}</td>
      <td class="edit"><input type="number" value="${b.budget||0}" data-bind="budgets.${i}.budget"></td>
      <td>${euro(spent)}</td><td>${euro(diff)}</td><td>${Math.round(usage)}%</td><td>${badge(st)}</td>
      <td style="min-width:180px">${progress(usage,statusClass(st))}</td>
      <td>${st==="Grün"?"Alles im Rahmen":st==="Gelb"?"Beobachten":"Sofort prüfen"}</td>
      <td><button class="small danger" data-action="delBudget" data-index="${i}">Löschen</button></td>
    </tr>`}).join("");
    return `${hero("Budgets","Sofort erkennen: Wo läuft es gut? Wo läuft es schlecht?",["Grün = gut","Gelb = beobachten","Rot = prüfen"])}
    <div class="actions"><button class="primary-btn" data-action="addBudget">Budget ergänzen</button></div>
    ${table({title:"Budgetsteuerung",note:"Ampeln nach PARAMETER-Schwellen",cols:["Kategorie","Budget","Ist","Differenz","Auslastung","Status","Balken","Hinweis",""]},rows)}`;
  },
  PLANUNG(){
    const months=[...Array(12)].map((_,i)=>addMonths(state.activeMonth,i));
    const previewRows=months.map(m=>{
      const special=specialForMonth(m);
      const plannedBudgets=state.budgets.reduce((s,b)=>s+Number(b.budget||0),0);
      const rest=Number(state.params.income||0)-fixedTotal()-plannedBudgets-special;
      return `<tr><td>${formatMonth(m)}</td><td>${euro(state.params.income)}</td><td>${euro(fixedTotal())}</td><td>${euro(plannedBudgets)}</td><td>${euro(special)}</td><td>${euro(rest)}</td><td>${rest>=0?badge("Grün"):badge("Rot")}</td></tr>`
    }).join("");
    const specialRows=state.special.map((s,i)=>`<tr><td class="edit"><input type="month" value="${s.month||state.activeMonth}" data-bind="special.${i}.month"></td><td class="edit"><input value="${escapeAttr(s.desc||"")}" data-bind="special.${i}.desc"></td><td class="edit"><input type="number" value="${s.amount||0}" data-bind="special.${i}.amount"></td><td><button class="small danger" data-action="delSpecial" data-index="${i}">Löschen</button></td></tr>`).join("");
    return `${hero("Planung","Vorausdenken: Was bleibt übrig? Was kommt nächsten Monat? Welche Sonderkosten kommen?",["12 Monate","Sonderkosten","Restbetrag"])}
    <div class="actions"><button class="primary-btn" data-action="addSpecial">Sonderkosten ergänzen</button></div>
    ${table({title:"Sonderkosten",note:"zukünftige Ausgaben planen",cols:["Monat","Beschreibung","Betrag",""]},specialRows)}
    ${table({title:"Vorschau",note:"lesbare Monate statt Serienzahlen",cols:["Monat","Einnahmen","Fixkosten","Budget geplant","Sonderkosten","Rest","Status"]},previewRows)}`;
  },
  MONAT(){
    return `${hero("Monatsanalyse","Der Monat als Auswertung: Einnahmen, Ausgaben, Sparquote, größte Kosten und Entwicklung.",["Analyse","Kostenbereiche","Sparquote"])}
    <div class="grid grid-4">${kpi("Einnahmen",euro(incomeForMonth()),"gesamt")}${kpi("Ausgaben",euro(expensesForMonth()),"gesamt")}${kpi("Sparquote",pct(savingsRateForMonth()),"vom Einkommen")}${kpi("Budgetstatus",badge(budgetStatusForMonth()),"automatisch")}</div>
    <div class="grid grid-2">
      <div class="card"><div class="section-title"><h3>Kostenbereiche</h3><span>${state.activeMonth}</span></div>${bars(state.budgets.map(b=>[b.category,categorySpent(b.category),Math.max(...state.budgets.map(x=>categorySpent(x.category)),1)]))}</div>
      <div class="card chart-card"><div class="section-title"><h3>Trend</h3><span>6 Monate</span></div><div class="chart">${lineChart(lastMonths(state.activeMonth,6))}</div></div>
    </div>`;
  },
  HINWEISE(){
    return `${hero("Persönlicher Finanzcoach","Warnungen, Tipps und Auffälligkeiten in normaler Sprache. Keine Techniktexte.",["Priorität","Warum wichtig","Nächste Aktion"])}
    <div class="coach-list">${buildCoach(state.activeMonth).map(coachItem).join("")}</div>`;
  },
  MONATSABSCHLUSS(){
    const checks=["Alle Einnahmen erfasst","Alle Ausgaben erfasst","Fixkosten geprüft","Budgets plausibel","Notgroschen aktualisiert","Sparziele aktualisiert","Monat bewusst abgeschlossen"];
    const rows=checks.map((c,i)=>`<tr><td>${c}</td><td class="edit"><select data-bind="checks.${i}"><option ${state.checks[i]==="Offen"?"selected":""}>Offen</option><option ${state.checks[i]==="OK"?"selected":""}>OK</option></select></td><td>${state.checks[i]==="OK"?badge("Grün"):badge("Gelb")}</td></tr>`).join("");
    return `${hero("Monatsabschluss","Kontrollzentrum: Sind alle Buchungen vollständig und die Budgets plausibel?",["Checkliste","OK / Offen","Monat abschließen"])}
    ${table({title:"Prüfpunkte",note:"Gelb bearbeiten",cols:["Prüfung","Status","Ampel"]},rows)}`;
  },
  JAHR(){
    const yearStart = state.activeMonth.slice(0,4)+"-01";
    const months=[...Array(12)].map((_,i)=>addMonths(yearStart,i));
    const rows=months.map(m=>`<tr><td>${formatMonth(m)}</td><td>${euro(incomeForMonth(m))}</td><td>${euro(expensesForMonth(m))}</td><td>${euro(saldoForMonth(m))}</td><td>${pct(savingsRateForMonth(m))}</td><td>${pct(reserveProgress())}</td><td>${badge(budgetStatusForMonth(m))}</td></tr>`).join("");
    return `${hero("Jahresüberblick","Monat für Monat sehen: Entwicklung, Trends, Notgroschen und Budgetstatus. Jeder Monat wird separat berechnet.",["Historisch je Monat","Jahrestrend","Überblick"])}
    <div class="card chart-card"><div class="section-title"><h3>Jahresentwicklung</h3><span>Einnahmen, Ausgaben, Saldo</span></div><div class="chart">${lineChart(months)}</div></div>
    ${table({title:"Jahr",note:"Budgetstatus je Monat neu berechnet",cols:["Monat","Einnahmen","Ausgaben","Saldo","Sparquote","Notgroschen","Budgetstatus"]},rows)}`;
  },
  NOTGROSCHEN(){
    const prog=reserveProgress(), target=Number(state.params.reserveGoal||0), cur=Number(state.reserve.current||0);
    const months= state.reserve.monthly>0 ? Math.ceil(Math.max(0,target-cur)/state.reserve.monthly) : "—";
    return `${hero("Notgroschen","Finanzielle Sicherheit sichtbar machen: aktueller Stand, Ziel, Fortschritt und Reichweite.",["Sicherheit","Fortschritt","Reichweite"])}
    <div class="grid grid-4">${kpi("Aktuell",euro(cur),"vorhanden")}${kpi("Ziel",euro(target),"gewünscht")}${kpi("Fortschritt",pct(prog),progress(prog,"ok"))}${kpi("Zeit bis Ziel",months+" Monate","bei aktueller Rate")}</div>
    <div class="card">${formCardInner("Bausteine",[["Aktueller Stand","reserve.current","number"],["Monatliche Rate","reserve.monthly","number"]])}</div>`;
  },
  SCHULDEN(){
    const rows=state.debts.map((d,i)=>{
      const months=d.rate?Math.ceil(Number(d.balance||0)/Math.max(1,Number(d.rate||1))):"—";
      return `<tr><td class="edit"><input value="${escapeAttr(d.name)}" data-bind="debts.${i}.name"></td><td class="edit"><input type="number" value="${d.balance||0}" data-bind="debts.${i}.balance"></td><td class="edit"><input type="number" value="${d.rate||0}" data-bind="debts.${i}.rate"></td><td>${months}</td><td>${progress(d.rate?Math.min(100,(Number(d.rate||0)/Math.max(1,Number(d.balance||0)))*100):0,"warn")}</td><td><button class="small danger" data-action="delDebt" data-index="${i}">Löschen</button></td></tr>`;
    }).join("");
    return `${hero("Schulden","Kontrolle statt Druck: Restschuld, Rate, Dauer und Fortschritt.",["Restschuld","Rate","Fortschritt"])}
    <div class="actions"><button class="primary-btn" data-action="addDebt">Schuld ergänzen</button></div>
    ${table({title:"Abbauplan",note:"Gelb bearbeiten",cols:["Schuld","Restschuld","Rate","Dauer Monate","Fortschritt",""]},rows)}`;
  },
  STEUER(){
    const rows=state.taxes.map((t,i)=>`<tr><td class="edit"><input value="${escapeAttr(t.name)}" data-bind="taxes.${i}.name"></td><td class="edit"><input type="number" value="${t.amount||0}" data-bind="taxes.${i}.amount"></td><td class="edit"><input value="${escapeAttr(t.note||"")}" data-bind="taxes.${i}.note"></td><td><button class="small danger" data-action="delTax" data-index="${i}">Löschen</button></td></tr>`).join("");
    return `${hero("Steuer","Steuerrelevante Beträge sammeln und Ordnung schaffen.",["Jahreswerte","Rücklagen","Positionen"])}
    <div class="grid grid-3">${kpi("Summe",euro(state.taxes.reduce((s,t)=>s+Number(t.amount||0),0)),"steuerrelevant")}${kpi("Positionen",state.taxes.length,"erfasst")}${kpi("Status",badge("Grün"),"geordnet")}</div>
    <div class="actions"><button class="primary-btn" data-action="addTax">Position ergänzen</button></div>
    ${table({title:"Steuerpositionen",note:"Gelb bearbeiten",cols:["Position","Betrag","Notiz",""]},rows)}`;
  },
  SPARZIELE(){
    const rows=state.goals.map((g,i)=>{
      const prog=Math.min(100,Number(g.current||0)/Math.max(1,Number(g.goal||1))*100), fehl=Math.max(0,Number(g.goal||0)-Number(g.current||0));
      const months=g.monthly?Math.ceil(fehl/Math.max(1,Number(g.monthly||1))):"—";
      return `<tr><td class="edit"><input value="${escapeAttr(g.name)}" data-bind="goals.${i}.name"></td><td class="edit"><input type="number" value="${g.goal||0}" data-bind="goals.${i}.goal"></td><td class="edit"><input type="number" value="${g.current||0}" data-bind="goals.${i}.current"></td><td>${euro(fehl)}</td><td class="edit"><input type="number" value="${g.monthly||0}" data-bind="goals.${i}.monthly"></td><td>${months}</td><td>${progress(prog,"ok")}</td><td><button class="small danger" data-action="delGoal" data-index="${i}">Löschen</button></td></tr>`;
    }).join("");
    return `${hero("Sparziele","Ziele sichtbar machen: Urlaub, Auto, PC, Notgroschen oder frei wählbare Wünsche.",["Motivation","Fehlbetrag","Zeit bis Ziel"])}
    <div class="actions"><button class="primary-btn" data-action="addGoal">Sparziel ergänzen</button></div>
    ${table({title:"Ziele",note:"Fortschritt automatisch",cols:["Ziel","Soll","Ist","Fehlbetrag","Monatsrate","Zeit bis Ziel","Fortschritt",""]},rows)}`;
  },
  LIZENZ(){
    return `${hero("Lizenz","Sauberer Abschluss: Nutzung, Kontakt, Version und Hinweis zur App.",["Seriös","Ruhig","Juristisch sauber"])}
    <div class="grid grid-2">
      <div class="card"><h3>Nutzung</h3><p class="mini-muted">Diese lokale App ist für die private Finanzorganisation bestimmt. Weitergabe, Weiterverkauf oder öffentliche Bereitstellung nur mit entsprechender Erlaubnis.</p></div>
      <div class="card"><h3>Version</h3><p class="mini-muted">EGO Budgetstarter · lokale App · keine Nutzungleistung enthalten</p></div>
    </div>`;
  }
};

function kpi(label,value,note){return `<div class="card kpi-card"><div class="kpi-label">${label}</div><div class="kpi-value">${value}</div><div class="kpi-note">${note}</div></div>`;}
function formCard(title, fields){return `<div class="card"><div class="section-title"><h3>${title}</h3><span>Gelb = Eingabe</span></div>${formCardInner(title,fields)}</div>`}
function formCardInner(title, fields){return `<div class="form-grid">${fields.map(f=>`<div class="field"><label>${f[0]}</label>${input(f[1],f[2]||"text")}</div>`).join("")}</div>`}
function simpleList(title,key){
  return `<div class="card"><div class="section-title"><h3>${title}</h3><span>${state[key].length} Werte</span></div>
  <div class="coach-list">${state[key].map((x,i)=>`<div class="coach-item"><span class="badge neutral">${i+1}</span><input data-bind="${key}.${i}" value="${escapeAttr(x)}"><button class="small danger" data-action="delList" data-key="${key}" data-index="${i}">Löschen</button></div>`).join("")}</div>
  <button class="primary-btn" data-action="addList" data-key="${key}" style="margin-top:14px">Wert ergänzen</button></div>`;
}
function bars(items){
  const max=Math.max(...items.map(x=>Number(x[2]||x[1]||1)),1);
  return items.map(([label,val,cap])=>`<div class="bar-row"><div class="mini-muted">${label}</div>${progress((val/(cap||max))*100,"warn")}<strong>${euro(val)}</strong></div>`).join("");
}
function buildCoach(month=state.activeMonth){
  const list=[];
  if(amountEntries("Einnahme",month)<=0) list.push(["Hoch","Einnahmen erfassen","Ohne Einnahmen ist der Monatsstatus nicht aussagekräftig.","Trage deine Einnahmen im Haushaltsbuch ein."]);
  if(budgetStatusForMonth(month)==="Rot") list.push(["Hoch","Budget überschritten","Mindestens ein Budget liegt über der kritischen Schwelle.","Öffne BUDGETS und prüfe die roten Bereiche."]);
  if(reserveProgress()<25) list.push(["Mittel","Notgroschen aufbauen","Deine Sicherheitsreserve ist noch niedrig.","Lege eine feste Monatsrate im Notgroschen-Blatt fest."]);
  if(savingsRateForMonth(month)<Number(state.params.savingsRateGoal||0)) list.push(["Mittel","Sparquote verbessern",`Du liegst unter deinem Ziel von ${state.params.savingsRateGoal}%.`,"Prüfe flexible Ausgaben und setze ein realistisches Monatsziel."]);
  if(saldoForMonth(month)<0) list.push(["Hoch","Monat kippt ins Minus","Die Ausgaben liegen über den Einnahmen.","Sofort Fixkosten und variable Ausgaben prüfen."]);
  const over = state.budgets.map(b=>({cat:b.category, over:categorySpent(b.category, month)-Number(b.budget||0)})).filter(x=>x.over>0).sort((a,b)=>b.over-a.over)[0];
  if(over) list.push(["Hoch",`${over.cat} um ${euro(over.over)} über Plan`,`Dieser Bereich liegt konkret über deinem Budget.`,"Prüfe einzelne Buchungen und reduziere dort zuerst."]);
  if(list.length===0) list.push(["Niedrig","Monat wirkt stabil","Die wichtigsten Kennzahlen liegen im Rahmen.","Monat prüfen und weiter fortschreiben."]);
  return list;
}
function coachItem(c){const cls=c[0]==="Hoch"?"bad":c[0]==="Mittel"?"warn":"ok";return `<div class="coach-item"><span class="badge ${cls}">${c[0]}</span><div><strong>${c[1]}</strong><p>${c[2]}</p></div><span class="mini-muted">${c[3]}</span></div>`}
function genericPage(name){return `${hero(name,"Dieser Bereich folgt denselben Regeln: Gelb = Eingabe, Weiß = Automatik, Blau/Gold = Orientierung.",["Käuferführung","Automatik","Ergebnis"])}`}

function addMonths(ym,n){const d=new Date(ym+"-01T00:00:00"); d.setMonth(d.getMonth()+n); return d.toISOString().slice(0,7)}
function lastMonths(ym,n){return [...Array(n)].map((_,i)=>addMonths(ym, i-n+1))}
function formatMonth(ym){return new Date(ym+"-01T00:00:00").toLocaleDateString("de-DE",{month:"long",year:"numeric"})}
function escapeAttr(s){return String(s??"").replaceAll("&","&amp;").replaceAll('"',"&quot;").replaceAll("<","&lt;");}

function lineChart(months){
  const series=[
    {name:"Einnahmen", cls:"line-income", vals:months.map(incomeForMonth)},
    {name:"Ausgaben", cls:"line-expense", vals:months.map(expensesForMonth)},
    {name:"Saldo", cls:"line-saldo", vals:months.map(saldoForMonth)}
  ];
  const all=series.flatMap(s=>s.vals);
  const max=Math.max(...all,1), min=Math.min(...all,0);
  const W=760,H=240,L=44,R=18,T=22,B=40;
  const x=i=>L+(W-L-R)*(months.length<=1?0:i/(months.length-1));
  const y=v=>T+(H-T-B)*(1-(v-min)/Math.max(1,max-min));
  const paths=series.map(s=>`<path class="chart-line ${s.cls}" d="${s.vals.map((v,i)=>(i?'L':'M')+x(i).toFixed(1)+' '+y(v).toFixed(1)).join(' ')}"/>`).join("");
  const labels=months.map((m,i)=>`<text x="${x(i)}" y="${H-12}" text-anchor="middle" class="axis-label">${m.slice(5)}</text>`).join("");
  const legend=series.map((s,i)=>`<text x="${L+i*150}" y="14" class="axis-label">${s.name}</text>`).join("");
  return `<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="Monatstrend">
    <line x1="${L}" y1="${y(0)}" x2="${W-R}" y2="${y(0)}" stroke="#DDE5F0" stroke-width="1"/>
    ${legend}${paths}${labels}
  </svg>`;
}

const actions = {
  saveExcel(){exportExcelFile();},
  loadExcel(d){},
  addEntry(){const limit=entryLimit(); if(Number.isFinite(limit) && state.entries.length>=limit){toast(`Budgetstarter ist auf ${limit} Buchungen begrenzt.`); return;} state.entries.push({date:new Date().toISOString().slice(0,10),desc:"",category:state.categories[0]||"",type:"Ausgabe",amount:0,payment:state.payments[0]||"",note:""}); saveSilent(); render();},
  delEntry(d){if(confirm("Buchung löschen?")){state.entries.splice(Number(d.index),1); saveSilent(); render();}},
  addFixed(){state.fixed.push({name:"",category:state.categories[0]||"",rhythm:"Monatlich",amount:0}); render();},
  delFixed(d){if(confirm("Fixkosten-Eintrag löschen?")){state.fixed.splice(Number(d.index),1); saveSilent(); render();}},
  addBudget(){state.budgets.push({category:state.categories[0]||"",budget:0}); render();},
  delBudget(d){if(confirm("Budget löschen?")){state.budgets.splice(Number(d.index),1); saveSilent(); render();}},
  addSpecial(){state.special.push({month:addMonths(state.activeMonth,1),desc:"",amount:0}); render();},
  delSpecial(d){if(confirm("Sonderkosten löschen?")){state.special.splice(Number(d.index),1); saveSilent(); render();}},
  addDebt(){state.debts.push({name:"",balance:0,rate:0,interest:0}); render();},
  delDebt(d){if(confirm("Schuld löschen?")){state.debts.splice(Number(d.index),1); saveSilent(); render();}},
  addTax(){state.taxes.push({name:"",amount:0,note:""}); render();},
  delTax(d){if(confirm("Steuerposition löschen?")){state.taxes.splice(Number(d.index),1); saveSilent(); render();}},
  addGoal(){state.goals.push({name:"",goal:0,current:0,monthly:0}); render();},
  delGoal(d){if(confirm("Sparziel löschen?")){state.goals.splice(Number(d.index),1); saveSilent(); render();}},
  addList(d){state[d.key].push("Neuer Wert"); render();},
  delList(d){if(confirm("Wert löschen?")){state[d.key].splice(Number(d.index),1); saveSilent(); render();}}
};

function exportJson(){
  const blob=new Blob([JSON.stringify(state,null,2)],{type:"application/json"});
  const a=document.createElement("a"); a.href=URL.createObjectURL(blob); a.download="ego-daten.json"; a.click();
}
function importJson(e){
  const file=e.target.files[0]; if(!file) return;
  const reader=new FileReader();
  reader.onload=()=>{try{state=normalize(JSON.parse(reader.result)); enforceProductLimits(true); save(); render();}catch{toast("Import nicht möglich");}};
  reader.readAsText(file);
}


function xmlEscape(value){
  return String(value ?? "")
    .replaceAll("&","&amp;")
    .replaceAll("<","&lt;")
    .replaceAll(">","&gt;")
    .replaceAll('"',"&quot;");
}
function excelCell(value){
  const isNum = typeof value === "number" && Number.isFinite(value);
  const type = isNum ? "Number" : "String";
  return `<Cell><Data ss:Type="${type}">${xmlEscape(value)}</Data></Cell>`;
}
function excelRow(values){ return `<Row>${values.map(excelCell).join("")}</Row>`; }
function excelSheet(name, rows){
  return `<Worksheet ss:Name="${xmlEscape(name.slice(0,31))}"><Table>${rows.map(excelRow).join("")}</Table></Worksheet>`;
}
function excelWorkbookXml(){
  const sheets = [];
  sheets.push(excelSheet("PARAMETER", [
    ["Feld","Wert"],
    ["Name", state.params.name],
    ["Startmonat", state.params.startMonth],
    ["Einkommen", state.params.income],
    ["Notgroschen-Ziel", state.params.reserveGoal],
    ["Sparquote-Ziel %", state.params.savingsRateGoal],
    ["Budget-Warnung %", state.params.budgetWarn],
    ["Budget kritisch %", state.params.budgetCritical]
  ]));
  sheets.push(excelSheet("KATEGORIEN", [["Kategorie"], ...state.categories.map(x=>[x])]));
  sheets.push(excelSheet("ZAHLUNGSARTEN", [["Zahlungsart"], ...state.payments.map(x=>[x])]));
  sheets.push(excelSheet("HAUSHALTSBUCH", [
    ["Datum","Beschreibung","Kategorie","Typ","Betrag","Zahlungsart","Notiz"],
    ...state.entries.map(e=>[e.date,e.desc,e.category,e.type,Number(e.amount||0),e.payment,e.note||""])
  ]));
  sheets.push(excelSheet("FIXKOSTEN", [
    ["Name","Kategorie","Rhythmus","Betrag"],
    ...state.fixed.map(f=>[f.name,f.category,f.rhythm,Number(f.amount||0)])
  ]));
  sheets.push(excelSheet("BUDGETS", [
    ["Kategorie","Budget"],
    ...state.budgets.map(b=>[b.category,Number(b.budget||0)])
  ]));
  sheets.push(excelSheet("SONDERKOSTEN", [
    ["Monat","Beschreibung","Betrag"],
    ...state.special.map(s=>[s.month,s.desc,Number(s.amount||0)])
  ]));
  sheets.push(excelSheet("NOTGROSCHEN", [
    ["Feld","Wert"],
    ["Aktueller Stand", Number(state.reserve.current||0)],
    ["Monatliche Rate", Number(state.reserve.monthly||0)]
  ]));
  sheets.push(excelSheet("SCHULDEN", [
    ["Name","Restschuld","Rate","Zins"],
    ...state.debts.map(d=>[d.name,Number(d.balance||0),Number(d.rate||0),Number(d.interest||0)])
  ]));
  sheets.push(excelSheet("STEUER", [
    ["Position","Betrag","Notiz"],
    ...state.taxes.map(t=>[t.name,Number(t.amount||0),t.note||""])
  ]));
  sheets.push(excelSheet("SPARZIELE", [
    ["Ziel","Soll","Ist","Monatsrate"],
    ...state.goals.map(g=>[g.name,Number(g.goal||0),Number(g.current||0),Number(g.monthly||0)])
  ]));
  return `<?xml version="1.0"?>
<?mso-application progid="Excel.Sheet"?>
<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"
 xmlns:o="urn:schemas-microsoft-com:office:office"
 xmlns:x="urn:schemas-microsoft-com:office:excel"
 xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">
 <DocumentProperties xmlns="urn:schemas-microsoft-com:office:office">
  <Author>EGO</Author>
  <Created>${new Date().toISOString()}</Created>
 </DocumentProperties>
 <Styles>
  <Style ss:ID="Default" ss:Name="Normal"><Alignment ss:Vertical="Center"/><Font ss:FontName="Segoe UI" ss:Size="11"/></Style>
 </Styles>
 ${sheets.join("\n")}
</Workbook>`;
}
function exportExcelFile(){
  saveSilent();
  const blob = new Blob([excelWorkbookXml()], {type:"application/vnd.ms-excel;charset=utf-8"});
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = `EGO_Daten_${new Date().toISOString().slice(0,10)}.xls`;
  a.click();
  setTimeout(()=>URL.revokeObjectURL(a.href), 1000);
  toast("Excel-Datei gespeichert");
}
function sheetRowsFromXml(doc, sheetName){
  const sheets = Array.from(doc.getElementsByTagName("Worksheet"));
  const sheet = sheets.find(s => s.getAttribute("ss:Name") === sheetName || s.getAttribute("Name") === sheetName);
  if(!sheet) return [];
  return Array.from(sheet.getElementsByTagName("Row")).map(row =>
    Array.from(row.getElementsByTagName("Cell")).map(cell => {
      const data = cell.getElementsByTagName("Data")[0];
      return data ? data.textContent : "";
    })
  );
}
function num(v){ const n = Number(String(v ?? "").replace(",", ".")); return Number.isFinite(n) ? n : 0; }
function importKeyValue(rows){
  const obj = {};
  rows.slice(1).forEach(r => { if(r[0]) obj[r[0]] = r[1] ?? ""; });
  return obj;
}
function importExcelFile(event){
  const file = event.target.files && event.target.files[0];
  if(!file) return;
  const reader = new FileReader();
  reader.onload = () => {
    try{
      const doc = new DOMParser().parseFromString(reader.result, "text/xml");
      if(doc.getElementsByTagName("parsererror").length) throw new Error("XML konnte nicht gelesen werden.");

      const p = importKeyValue(sheetRowsFromXml(doc, "PARAMETER"));
      state.params.name = p["Name"] ?? state.params.name;
      state.params.startMonth = p["Startmonat"] ?? state.params.startMonth;
      state.params.income = num(p["Einkommen"]);
      state.params.reserveGoal = num(p["Notgroschen-Ziel"]);
      state.params.savingsRateGoal = num(p["Sparquote-Ziel %"]);
      state.params.budgetWarn = num(p["Budget-Warnung %"]) || state.params.budgetWarn;
      state.params.budgetCritical = num(p["Budget kritisch %"]) || state.params.budgetCritical;

      const cats = sheetRowsFromXml(doc, "KATEGORIEN").slice(1).map(r=>r[0]).filter(Boolean);
      if(cats.length) state.categories = cats;
      const pays = sheetRowsFromXml(doc, "ZAHLUNGSARTEN").slice(1).map(r=>r[0]).filter(Boolean);
      if(pays.length) state.payments = pays;

      state.entries = sheetRowsFromXml(doc, "HAUSHALTSBUCH").slice(1).filter(r=>r.some(Boolean)).map(r=>({
        date:r[0]||"", desc:r[1]||"", category:r[2]||"", type:r[3]||"Ausgabe", amount:num(r[4]), payment:r[5]||"", note:r[6]||""
      }));
      state.fixed = sheetRowsFromXml(doc, "FIXKOSTEN").slice(1).filter(r=>r.some(Boolean)).map(r=>({
        name:r[0]||"", category:r[1]||"", rhythm:r[2]||"Monatlich", amount:num(r[3])
      }));
      state.budgets = sheetRowsFromXml(doc, "BUDGETS").slice(1).filter(r=>r.some(Boolean)).map(r=>({
        category:r[0]||"", budget:num(r[1])
      }));
      state.special = sheetRowsFromXml(doc, "SONDERKOSTEN").slice(1).filter(r=>r.some(Boolean)).map(r=>({
        month:r[0]||"", desc:r[1]||"", amount:num(r[2])
      }));
      const reserve = importKeyValue(sheetRowsFromXml(doc, "NOTGROSCHEN"));
      state.reserve.current = num(reserve["Aktueller Stand"]);
      state.reserve.monthly = num(reserve["Monatliche Rate"]);

      state.debts = sheetRowsFromXml(doc, "SCHULDEN").slice(1).filter(r=>r.some(Boolean)).map(r=>({
        name:r[0]||"", balance:num(r[1]), rate:num(r[2]), interest:num(r[3])
      }));
      state.taxes = sheetRowsFromXml(doc, "STEUER").slice(1).filter(r=>r.some(Boolean)).map(r=>({
        name:r[0]||"", amount:num(r[1]), note:r[2]||""
      }));
      state.goals = sheetRowsFromXml(doc, "SPARZIELE").slice(1).filter(r=>r.some(Boolean)).map(r=>({
        name:r[0]||"", goal:num(r[1]), current:num(r[2]), monthly:num(r[3])
      }));
      enforceProductLimits(true);
      save();
      render();
      toast("Excel-Datei geladen");
    }catch(err){
      console.error(err);
      toast("Excel-Datei konnte nicht geladen werden");
    }finally{
      event.target.value = "";
    }
  };
  reader.readAsText(file, "utf-8");
}

window.addEventListener("beforeunload", saveSilent);
init();
